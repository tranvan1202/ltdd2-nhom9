package com.example.testrecycler.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper( Context context) {
        super(context, "QLDDH.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlKH = "CREATE TABLE " + "QLKH" +
                " (" + "_id" + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "makh" + " TEXT, " +
                "tenkh" + " TEXT, " +
                "diachi" + " TEXT, " +
                "sodt" + " INTEGER);";

        String sqlSP = "CREATE TABLE " + "QLSP" +
                " (" + "_id" + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "masp" + " TEXT, " +
                "tensp" + " TEXT, " +
                "xuatxu" + " TEXT, " +
                "dongia" + " INTEGER);";

        String sqlDH = "CREATE TABLE " + "QLDH" +
                " (" + "_id" + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "madh" + " TEXT, " +
                "makh" + " TEXT, " +
                "masp" + " TEXT, " +
                "soluongdat" + " INTEGER, " +
                "ngaytaodh" + " TEXT);";

        db.execSQL(sqlKH);
        db.execSQL(sqlSP);
        db.execSQL(sqlDH);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "QLKH");
        db.execSQL("DROP TABLE IF EXISTS " + "QLSP");
        db.execSQL("DROP TABLE IF EXISTS " + "QLDH");
        onCreate(db);
    }
}
