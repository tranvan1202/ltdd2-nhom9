package com.example.testrecycler.Model;

public class SanPham {
    String maSP,tenSP,xuatXu, donGia;
    Integer sttSP;

    public SanPham() {
    }

    public SanPham(String maSP, String tenSP, String xuatXu, String donGia) {
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.xuatXu = xuatXu;
        this.donGia = donGia;
    }

    public SanPham(Integer sttSP, String maSP, String tenSP, String xuatXu, String donGia) {
        this.sttSP = sttSP;
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.xuatXu = xuatXu;
        this.donGia = donGia;
    }

    public Integer getSttSP() { return sttSP; }

    public void setSttSP(Integer sttSP) { this.sttSP = sttSP; }
    public String getMaSP() { return maSP; }

    public void setMaSP(String maSP) { this.maSP = maSP; }

    public String getTenSP() { return tenSP; }

    public void setTenSP(String tenSP) { this.tenSP = tenSP; }

    public String getXuatXu() { return xuatXu; }

    public void setXuatXu(String xuatXu) { this.xuatXu = xuatXu; }

    public String getDonGia() { return donGia; }

    public void setDonGia(String donGia) { this.donGia = donGia; }

    @Override
    public String toString() {
        return "SanPham{" +
                "maSP='" + maSP + '\'' +
                ", tenSP='" + tenSP + '\'' +
                ", xuatXu='" + xuatXu + '\'' +
                ", sttSP=" + sttSP +
                ", donGia=" + donGia +
                '}';
    }
}
