package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.testrecycler.Database.DBHelperKH;
import com.example.testrecycler.R;

public class ThemKHActivity extends AppCompatActivity {
    EditText edtMaKH, edtTenKH, edtDiaChi, edtSoDT;
    Button btnThem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_kh);
        setControl();
        setEvent();
    }

    private void setEvent() {
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperKH myDB = new DBHelperKH(ThemKHActivity.this);
                myDB.ThemKH(edtMaKH.getText().toString().trim(),
                        edtTenKH.getText().toString().trim(),
                        edtDiaChi.getText().toString().trim(),
                        Integer.valueOf(edtSoDT.getText().toString().trim()));
            }
        });
    }

    private void setControl() {
        edtMaKH = findViewById(R.id.nhapMaKH);
        edtTenKH = findViewById(R.id.nhapTen);
        edtDiaChi = findViewById(R.id.nhapDiaChi);
        edtSoDT = findViewById(R.id.nhapSoDT);
        btnThem = findViewById(R.id.add_button);
    }
}