package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testrecycler.Database.DBHelperKH;
import com.example.testrecycler.R;

public class SuaKHActivity extends AppCompatActivity {

    EditText edtMaKH, edtTenKH, edtDiaChi, edtSoDT;
    Button btnLuu, btnXoa;
    String id, maKH, tenKH, diaChi, soDT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_kh);
        setControl();
        setEvent();

        layDuLieuKH();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(maKH);
        }
    }

    private void setEvent() {
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperKH myDB =  new DBHelperKH(SuaKHActivity.this);
                maKH = edtMaKH.getText().toString().trim();
                tenKH = edtTenKH.getText().toString().trim();
                diaChi = edtDiaChi.getText().toString().trim();
                soDT = edtSoDT.getText().toString().trim();
                myDB.SuaKH(id,maKH,tenKH,diaChi,soDT);
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuKH(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("maKH") &&
                getIntent().hasExtra("tenKH") &&
                getIntent().hasExtra("diaChi") && getIntent().hasExtra("soDT")){
            //Getting Data from Intent
            id = getIntent().getStringExtra("id");
            maKH = getIntent().getStringExtra("maKH");
            tenKH = getIntent().getStringExtra("tenKH");
            diaChi = getIntent().getStringExtra("diaChi");
            soDT = getIntent().getStringExtra("soDT");

            //Setting Intent Data
            edtMaKH.setText(maKH);
            edtTenKH.setText(tenKH);
            edtDiaChi.setText(diaChi);
            edtSoDT.setText(soDT);
            Log.d("TranVan", maKH+" "+tenKH+" "+diaChi+ " " +soDT);
        }else{
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmXoa() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Xóa đi " + tenKH + " ?");
        builder.setMessage("Bạn có chắc muốn xóa " + tenKH + " không ?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBHelperKH myDB = new DBHelperKH(SuaKHActivity.this);
                myDB.XoaMotItemKH(id);
                finish();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    private void setControl() {
        edtMaKH = findViewById(R.id.suaMaKH);
        edtTenKH = findViewById(R.id.suaTen);
        edtDiaChi = findViewById(R.id.suaDiaChi);
        edtSoDT = findViewById(R.id.suaSoDT);
        btnLuu = findViewById(R.id.save_button);
        btnXoa = findViewById(R.id.delete_button);
    }
}