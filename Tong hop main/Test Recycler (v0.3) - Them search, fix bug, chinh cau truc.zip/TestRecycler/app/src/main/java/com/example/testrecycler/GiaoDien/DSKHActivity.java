package com.example.testrecycler.GiaoDien;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.testrecycler.Adapter.CustomAdapterKH;
import com.example.testrecycler.Database.DBKhachHang;
import com.example.testrecycler.Model.KhachHang;
import com.example.testrecycler.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class DSKHActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton add_button;
    ImageView img_empty;
    TextView khongDuLieu;

    ArrayList<KhachHang> data = new ArrayList<>();
    DBKhachHang myDB = new DBKhachHang(DSKHActivity.this);
    CustomAdapterKH customAdapterKH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_kh);
        setControl();
        setEvent();

        luuDatabaseVaoArrays();

        customAdapterKH = new CustomAdapterKH(DSKHActivity.this,this, data);
        recyclerView.setAdapter(customAdapterKH);
        recyclerView.setLayoutManager(new LinearLayoutManager(DSKHActivity.this));
    }

    private void setEvent() {
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DSKHActivity.this, ThemKHActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    public void luuDatabaseVaoArrays(){
        data = myDB.listKhachHangs();
        if(data.size() > 0){
            recyclerView.setVisibility(View.VISIBLE);
            customAdapterKH = new CustomAdapterKH(DSKHActivity.this,this, data);
            recyclerView.setAdapter(customAdapterKH);

        }else {
            recyclerView.setVisibility(View.GONE);
            img_empty.setVisibility(View.VISIBLE);
            khongDuLieu.setVisibility(View.VISIBLE);
            Toast.makeText(this,"Không có dữ liệu", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        search(searchView);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            confirmXoaTatCa();
        }

        return super.onOptionsItemSelected(item);
    }

    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (customAdapterKH!=null)
                    customAdapterKH.getFilter().filter(newText);
                return true;
            }
        });
    }

    void confirmXoaTatCa () {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Xóa tất cả?");
        builder.setMessage("Bạn có chắc muốn xóa tất cả dữ liệu không?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBKhachHang myDB = new DBKhachHang(DSKHActivity.this);
                myDB.XoaTatCaKH();
                //Tải lại Activity
                Intent intent = new Intent(DSKHActivity.this, DSKHActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    private void setControl() {
        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        img_empty = findViewById(R.id.image_empty);
        khongDuLieu = findViewById(R.id.no_data);
    }
}