package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testrecycler.Database.DBHelperKH;
import com.example.testrecycler.Model.KhachHang;
import com.example.testrecycler.R;

import java.util.ArrayList;

public class SuaKHActivity extends AppCompatActivity {

    EditText edtMaKH, edtTenKH, edtDiaChi, edtSoDT;
    Button btnLuu, btnXoa;

    KhachHang khachHang = new KhachHang();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_kh);
        setControl();
        setEvent();
        layDuLieuKH();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle("Thông tin mã " +  khachHang.getMaKH());
        }
    }

    private void setEvent() {
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperKH myDB =  new DBHelperKH(SuaKHActivity.this);
                khachHang.setMaKH(edtMaKH.getText().toString().trim());
                khachHang.setTenKH(edtTenKH.getText().toString().trim());
                khachHang.setDiaChi(edtDiaChi.getText().toString().trim());
                khachHang.setSoDT(edtSoDT.getText().toString().trim());
                myDB.SuaKH(khachHang);
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuKH(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("maKH") &&
                getIntent().hasExtra("tenKH") &&
                getIntent().hasExtra("diaChi") && getIntent().hasExtra("soDT")){
            //Getting Data from Intent
            khachHang.setSttKH(getIntent().getStringExtra("id"));
            khachHang.setMaKH(getIntent().getStringExtra("maKH"));
            khachHang.setTenKH(getIntent().getStringExtra("tenKH"));
            khachHang.setDiaChi(getIntent().getStringExtra("diaChi"));
            khachHang.setSoDT(getIntent().getStringExtra("soDT"));

            //Setting Intent Data
            edtMaKH.setText(khachHang.getMaKH());
            edtTenKH.setText(khachHang.getTenKH());
            edtDiaChi.setText(khachHang.getDiaChi());
            edtSoDT.setText(khachHang.getSoDT());
            Log.d("TranVan", khachHang.getMaKH()+" "+khachHang.getTenKH()+" "+khachHang.getDiaChi()+ " " +khachHang.getSoDT());
        } else {
            Toast.makeText(this, "Không có dữ liệu.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmXoa() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Xóa đi " + khachHang.getTenKH() + " ?");
        builder.setMessage("Bạn có chắc muốn xóa " + khachHang.getTenKH() + " không ?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBHelperKH myDB = new DBHelperKH(SuaKHActivity.this);
                myDB.XoaMotItemKH(khachHang);
                finish();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    private void setControl() {
        edtMaKH = findViewById(R.id.suaMaKH);
        edtTenKH = findViewById(R.id.suaTen);
        edtDiaChi = findViewById(R.id.suaDiaChi);
        edtSoDT = findViewById(R.id.suaSoDT);
        btnLuu = findViewById(R.id.save_button);
        btnXoa = findViewById(R.id.delete_button);
    }
}