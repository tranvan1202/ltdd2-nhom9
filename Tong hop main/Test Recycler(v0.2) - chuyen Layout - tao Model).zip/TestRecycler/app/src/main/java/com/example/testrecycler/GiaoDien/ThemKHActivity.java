package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.testrecycler.Database.DBHelperKH;
import com.example.testrecycler.Model.KhachHang;
import com.example.testrecycler.R;

public class ThemKHActivity extends AppCompatActivity {
    EditText edtMaKH, edtTenKH, edtDiaChi, edtSoDT;
    Button btnThem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_kh);
        setControl();
        setEvent();
    }

    private void setEvent() {
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KhachHang khachHang = new KhachHang();
                DBHelperKH myDB = new DBHelperKH(ThemKHActivity.this);
                khachHang.setMaKH(edtMaKH.getText().toString());
                khachHang.setTenKH(edtTenKH.getText().toString());
                khachHang.setDiaChi(edtDiaChi.getText().toString());
                khachHang.setSoDT(edtSoDT.getText().toString());
                myDB.ThemKH(khachHang);
            }
        });
    }

    private void setControl() {
        edtMaKH = findViewById(R.id.nhapMaKH);
        edtTenKH = findViewById(R.id.nhapTen);
        edtDiaChi = findViewById(R.id.nhapDiaChi);
        edtSoDT = findViewById(R.id.nhapSoDT);
        btnThem = findViewById(R.id.add_button);
    }
}