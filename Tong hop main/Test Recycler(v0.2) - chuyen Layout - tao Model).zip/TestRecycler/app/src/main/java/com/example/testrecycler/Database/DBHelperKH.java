package com.example.testrecycler.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.testrecycler.Model.KhachHang;

import androidx.annotation.Nullable;

public class DBHelperKH extends SQLiteOpenHelper {
    private Context context;
    public static final String DATABASE_NAME = "QLDH.db";
    private static final int DATABASE_VERSION = 1;

    //Khai báo table Khách Hàng
    private static final String TABLE_NAME_KH = "QLKH";
    private static final String COLUMN_ID_KH = "_id";
    private static final String COLUMN_MA_KH = "makh";
    private static final String COLUMN_TENKH = "tenkh";
    private static final String COLUMN_DIACHI_KH = "diachi";
    private static final String COLUMN_SODT_KH = "sodt";

    public DBHelperKH(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME_KH +
                " (" + COLUMN_ID_KH + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_MA_KH + " TEXT, " +
                COLUMN_TENKH + " TEXT, " +
                COLUMN_DIACHI_KH + " TEXT, " +
                COLUMN_SODT_KH + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_KH);
        onCreate(db);
    }

    public Cursor LayKH(){
        String query = "SELECT * FROM " + TABLE_NAME_KH;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    public void ThemKH(KhachHang khachHang){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        if (khachHang.getMaKH().isEmpty() || khachHang.getTenKH().isEmpty()
                || khachHang.getDiaChi().isEmpty() || khachHang.getSoDT().isEmpty()) {
            Toast.makeText(context, "Vui lòng điền đủ thông tin", Toast.LENGTH_SHORT).show();
        } else  {
            cv.put(COLUMN_MA_KH, khachHang.getMaKH());
            cv.put(COLUMN_TENKH, khachHang.getTenKH());
            cv.put(COLUMN_DIACHI_KH, khachHang.getDiaChi());
            cv.put(COLUMN_SODT_KH, khachHang.getSoDT());
            long result = db.insert(TABLE_NAME_KH,null, cv);
            if(result == -1){
                Toast.makeText(context, "Thêm thất bại", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(context, "Đã thêm!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void SuaKH(KhachHang khachHang){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MA_KH, khachHang.getMaKH());
        cv.put(COLUMN_TENKH, khachHang.getTenKH());
        cv.put(COLUMN_DIACHI_KH, khachHang.getDiaChi());
        cv.put(COLUMN_SODT_KH, khachHang.getSoDT());

        long result = db.update(TABLE_NAME_KH, cv, "_id=?", new String[]{khachHang.getSttKH()});
        if(result == -1){
            Toast.makeText(context, "Không thể sửa", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Đã sửa!", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaMotItemKH(KhachHang khachHang){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME_KH, "_id=?", new String[]{khachHang.getSttKH()});
        if(result == -1){
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Đã xóa.", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaTatCaKH(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME_KH);
    }

}
