package com.example.testrecycler.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.example.testrecycler.Model.KhachHang;

import java.util.ArrayList;

public class DBKhachHang {
    DBHelper dbHelper;
    Context context;
    public DBKhachHang(Context context) {
        dbHelper= new DBHelper(context);
        this.context = context;
    }

    public ArrayList<KhachHang> listKhachHangs(){
        String sql = "select * from " + "QLKH";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ArrayList<KhachHang> khachHangs = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()){
            do{
                String _id = (cursor.getString(0));
                String maKH = cursor.getString(1);
                String tenKH = cursor.getString(2);
                String diaChi = cursor.getString(3);
                String soDT = cursor.getString(4);
                khachHangs.add(new KhachHang(_id,maKH,tenKH,diaChi,soDT));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return khachHangs;
    }

    public void ThemKH(KhachHang khachHang){
        ContentValues values = new ContentValues();
        values.put("makh", khachHang.getMaKH());
        values.put("tenkh", khachHang.getTenKH());
        values.put("diachi", khachHang.getDiaChi());
        values.put("sodt", khachHang.getSoDT());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert("QLKH", null, values);
    }

    public void SuaKH(KhachHang khachHang){
        ContentValues values = new ContentValues();
        values.put("makh", khachHang.getMaKH());
        values.put("tenkh", khachHang.getTenKH());
        values.put("diachi", khachHang.getDiaChi());
        values.put("sodt", khachHang.getSoDT());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.update("QLKH", values, "_id"	+ "	= ?", new String[]{khachHang.getSttKH()});
    }

    public void XoaMotItemKH(KhachHang khachHang){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long result = db.delete("QLKH", "_id=?", new String[]{khachHang.getSttKH()});
        if(result == -1){
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Đã xóa.", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaTatCaKH(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM " + "QLKH");
        //RESET STT ID TỰ TĂNG
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + "QLKH" + "'");
    }

}
