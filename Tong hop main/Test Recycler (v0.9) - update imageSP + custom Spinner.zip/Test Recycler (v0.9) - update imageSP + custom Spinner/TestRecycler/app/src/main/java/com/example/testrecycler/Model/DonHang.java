package com.example.testrecycler.Model;

public class DonHang {
    Integer sttDH, soLuongDat;
    String maDH, maKH, maSP, ngayTaoDH;

    public DonHang() {
    }

    public DonHang(String maDH, String maKH, String maSP, Integer soLuongDat, String ngayTaoDH) {
        this.maDH = maDH;
        this.maKH = maKH;
        this.maSP = maSP;
        this.soLuongDat = soLuongDat;
        this.ngayTaoDH = ngayTaoDH;
    }

    public DonHang(Integer sttDH, String maDH, String maKH, String maSP, Integer soLuongDat, String ngayTaoDH) {
        this.sttDH = sttDH;
        this.maDH = maDH;
        this.maKH = maKH;
        this.maSP = maSP;
        this.soLuongDat = soLuongDat;
        this.ngayTaoDH = ngayTaoDH;
    }



    public Integer getSttDH() { return sttDH; }

    public void setSttDH(Integer sttDH) { this.sttDH = sttDH; }

    public String getMaDH() { return maDH; }

    public void setMaDH(String maDH) { this.maDH = maDH; }

    public String getMaKH() { return maKH; }

    public void setMaKH(String maKH) { this.maKH = maKH; }

    public String getMaSP() { return maSP; }

    public void setMaSP(String maSP) { this.maSP = maSP; }

    public Integer getSoLuongDat() { return soLuongDat; }

    public void setSoLuongDat(Integer soLuongDat) { this.soLuongDat = soLuongDat; }

    public String getNgayTaoDH() { return ngayTaoDH; }

    public void setNgayTaoDH(String ngayTaoDH) { this.ngayTaoDH = ngayTaoDH; }

    @Override
    public String toString() {
        return "DonHang{" +
                "sttDH=" + sttDH +
                ", maDH='" + maDH + '\'' +
                ", maKH='" + maKH + '\'' +
                ", maSP='" + maSP + '\'' +
                ", soLuongDat='" + soLuongDat + '\'' +
                ", ngayTaoDH='" + ngayTaoDH + '\'' +
                '}';
    }
}
