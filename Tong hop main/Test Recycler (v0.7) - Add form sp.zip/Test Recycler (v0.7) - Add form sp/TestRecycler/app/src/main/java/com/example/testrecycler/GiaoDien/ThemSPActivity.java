package com.example.testrecycler.GiaoDien;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testrecycler.Database.DBDonDatHang;
import com.example.testrecycler.Model.SanPham;
import com.example.testrecycler.R;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class ThemSPActivity extends AppCompatActivity  {
    EditText edtMaSP, edtTenSP, edtXuatXu, edtDonGia;
    Button btnThem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sp);
        setControl();
        setEvent();
        //Đổi tên actionbar theo ngôn ngữ đã đổi:
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.titleFormAddSP));
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addSanPhamVaoMang();
            }
        });
    }

    private void addSanPhamVaoMang() {
        DBDonDatHang myDB = new DBDonDatHang(this);
        final String maSP = edtMaSP.getText().toString();
        final String tenSP = edtTenSP.getText().toString();
        final String xuatXu = edtXuatXu.getText().toString();
        final String donGia = edtDonGia.getText().toString();

        if(TextUtils.isEmpty(maSP) || TextUtils.isEmpty(tenSP) || TextUtils.isEmpty(xuatXu)|| TextUtils.isEmpty(donGia)){
            String toastNull = ThemSPActivity.this.getResources().getString(R.string.alertNull);
            Toast.makeText(ThemSPActivity.this, toastNull, Toast.LENGTH_LONG).show();
        }
        else{
            String toastSuccess = ThemSPActivity.this.getResources().getString(R.string.alertSuccess);
            SanPham sanPham = new SanPham(maSP,tenSP,xuatXu,donGia);
            Toast.makeText(ThemSPActivity.this, toastSuccess, Toast.LENGTH_LONG).show();
            myDB.ThemSP(sanPham);
        }
    }
    private void setControl() {
        edtMaSP = findViewById(R.id.nhapMaSP);
        edtTenSP = findViewById(R.id.nhapTenSP);
        edtXuatXu = findViewById(R.id.nhapXuatXu);
        edtDonGia = findViewById(R.id.nhapDonGia);
        btnThem = findViewById(R.id.add_button_sp);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}
