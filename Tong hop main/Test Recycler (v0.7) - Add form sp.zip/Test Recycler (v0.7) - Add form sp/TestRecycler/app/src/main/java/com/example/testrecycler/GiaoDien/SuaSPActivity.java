package com.example.testrecycler.GiaoDien;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testrecycler.Database.DBDonDatHang;
import com.example.testrecycler.Model.SanPham;
import com.example.testrecycler.R;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SuaSPActivity extends AppCompatActivity {

    EditText edtMaSP, edtTenSP, edtXuatXu, edtDonGia;
    Button btnLuu, btnXoa;

    SanPham sanPham = new SanPham();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_sp);
        setControl();
        setEvent();
        layDuLieuSP();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            String titleFormEditSP = SuaSPActivity.this.getResources().getString(R.string.titleFormEditSP);
            ab.setTitle(titleFormEditSP + " " +  sanPham.getMaSP());
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaSanPhamVaoMang();
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }

    private void suaSanPhamVaoMang() {
        DBDonDatHang myDB =  new DBDonDatHang(this);
        final String maSP = edtMaSP.getText().toString();
        final String tenSP = edtTenSP.getText().toString();
        final String xuatXu = edtXuatXu.getText().toString();
        final String donGia = edtDonGia.getText().toString();

        if(TextUtils.isEmpty(maSP) || TextUtils.isEmpty(tenSP) || TextUtils.isEmpty(xuatXu)|| TextUtils.isEmpty(donGia)){
            String toastNull = SuaSPActivity.this.getResources().getString(R.string.alertNull);
            Toast.makeText(SuaSPActivity.this, toastNull, Toast.LENGTH_LONG).show();
        }
        else{
            String toastSuccess = SuaSPActivity.this.getResources().getString(R.string.alertSuccess);
            myDB.SuaSP(new SanPham(sanPham.getSttSP(),maSP,tenSP,xuatXu,donGia));
            Toast.makeText(SuaSPActivity.this, toastSuccess, Toast.LENGTH_LONG).show();
        }
    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuSP(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("maSP") &&
                getIntent().hasExtra("tenSP") &&
                getIntent().hasExtra("xuatXu") && getIntent().hasExtra("donGia")){
            //Getting Data from Intent
            int id = -1;
            sanPham.setSttSP(getIntent().getIntExtra("id",id));
            sanPham.setMaSP(getIntent().getStringExtra("maSP"));
            sanPham.setTenSP(getIntent().getStringExtra("tenSP"));
            sanPham.setXuatXu(getIntent().getStringExtra("xuatXu"));
            sanPham.setDonGia(getIntent().getStringExtra("donGia"));

            //Setting Intent Data
            edtMaSP.setText(sanPham.getMaSP());
            edtTenSP.setText(sanPham.getTenSP());
            edtXuatXu.setText(sanPham.getXuatXu());
            edtDonGia.setText(sanPham.getDonGia());
            //Log.d("TranVan", sanPham.getMaSP()+" "+sanPham.getTenSP()+" "+sanPham.getXuatXu()+ " " +sanPham.getDonGia());
        } else {
            String toastMessage = SuaSPActivity.this.getResources().getString(R.string.noData);
            Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

    void confirmXoa() {
        String toastTittle = SuaSPActivity.this.getResources().getString(R.string.confirmDeleteTitle);
        String toastMessage = SuaSPActivity.this.getResources().getString(R.string.confirmDeleteMessage);
        String toastYes = SuaSPActivity.this.getResources().getString(R.string.confirmYes);
        String toastNo = SuaSPActivity.this.getResources().getString(R.string.confirmNo);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(toastTittle + sanPham.getTenSP());
        builder.setMessage(toastMessage + sanPham.getTenSP());
        builder.setPositiveButton(toastYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBDonDatHang myDB = new DBDonDatHang(SuaSPActivity.this);
                myDB.XoaMotItemSP(sanPham);
                finish();
            }
        });
        builder.setNegativeButton(toastNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.create().show();
    }

    private void setControl() {
        edtMaSP = findViewById(R.id.suaMaSP);
        edtTenSP = findViewById(R.id.suaTenSP);
        edtXuatXu = findViewById(R.id.suaXuatXu);
        edtDonGia = findViewById(R.id.suaDonGia);
        btnLuu = findViewById(R.id.save_button_sp);
        btnXoa = findViewById(R.id.delete_button_sp);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}
