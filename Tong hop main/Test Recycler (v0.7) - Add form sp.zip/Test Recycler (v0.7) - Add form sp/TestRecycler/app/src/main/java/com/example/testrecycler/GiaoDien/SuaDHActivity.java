package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.testrecycler.Model.KhachHang;
import com.example.testrecycler.R;

public class SuaDHActivity extends AppCompatActivity {

    EditText edtMaDH, edtSoLuongSP, edtNgayTaoDH;
    Spinner spinnerMaKH, spinnerMaSP;
    Button btnLuuDH, btnXoaDH;

    KhachHang khachHang = new KhachHang();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_dh);
        setControl();
        setEvent();
        layDuLieuDH();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            String titleFormEditDH = SuaDHActivity.this.getResources().getString(R.string.titleFormEditDH);
            ab.setTitle(titleFormEditDH + " " +  khachHang.getMaKH());
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnLuuDH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaDonHangVaoMang();
            }
        });

        btnXoaDH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }

    private void suaDonHangVaoMang() {

    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuDH(){

    }

    void confirmXoa() {

    }

    private void setControl() {
        edtMaDH = findViewById(R.id.suaMaDH);
        edtSoLuongSP = findViewById(R.id.suaSoLuongSP);
        edtNgayTaoDH = findViewById(R.id.suaNgayTaoDH);
        spinnerMaKH = findViewById(R.id.suaSpinnerMaKH);
        spinnerMaSP = findViewById(R.id.suaSpinnerMaSP);
        btnLuuDH = findViewById(R.id.add_button_dh);
        btnXoaDH = findViewById(R.id.delete_button_dh);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}