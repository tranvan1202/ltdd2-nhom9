package com.example.testrecycler.GiaoDien;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.testrecycler.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainFragment extends Fragment implements View.OnClickListener {
    CardView cvKH,cvSP,cvDH,cvIn;
    private Context mContext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_trangchu,container,false);
        cvKH = view.findViewById(R.id.homeKH);
        cvSP = view.findViewById(R.id.homeSP);
        cvDH = view.findViewById(R.id.homeDH);
        cvIn = view.findViewById(R.id.homeIn);

        cvKH.setOnClickListener(this);
        cvSP.setOnClickListener(this);
        cvDH.setOnClickListener(this);

        //Đổi tên toolbar
        String toolbBarTitle = mContext.getResources().getString(R.string.app_name);
        ((MainActivity)getActivity()).setActionBarTitle(toolbBarTitle);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext=context;
    }

    @Override
    public void onClick(View view) {
        Fragment fragment = null;
        switch (view.getId()) {
            case R.id.homeKH:
                fragment = new Fragment_DSKH();
                replaceFragment(fragment);
                break;

            case R.id.homeSP:
                fragment = new Fragment_DSSP();
                replaceFragment(fragment);
                break;

            case R.id.homeDH:
                fragment = new Fragment_DSDH();
                replaceFragment(fragment);
                break;
        }
    }

    public void replaceFragment(Fragment someFragment) {
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.container_fragment, someFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
