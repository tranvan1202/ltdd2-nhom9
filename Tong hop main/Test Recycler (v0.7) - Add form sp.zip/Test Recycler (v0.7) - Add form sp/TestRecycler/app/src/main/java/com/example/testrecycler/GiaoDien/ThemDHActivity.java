package com.example.testrecycler.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.testrecycler.Database.DBDonDatHang;
import com.example.testrecycler.R;

import java.util.ArrayList;

public class ThemDHActivity extends AppCompatActivity {

    EditText edtMaDH, edtSoLuongSP, edtNgayTaoDH;
    Spinner spinnerMaKH, spinnerMaSP;
    Button btnThemDH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_dh);
        setControl();
        setEvent();
        //Đổi tên actionbar theo ngôn ngữ đã đổi:
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.titleFormAddDH));
        actionBar.setDisplayHomeAsUpEnabled(true);

        DBDonDatHang dbDonDatHang = new DBDonDatHang(this);
        ArrayList<String> listMaKH = dbDonDatHang.getAllKhachHangs();
        ArrayAdapter<String> adapterMaKH = new ArrayAdapter<String>(this, R.layout.spinner_layout_makh, R.id.tvSpinnerLayoutMaKH,listMaKH);
        spinnerMaKH.setAdapter(adapterMaKH);
        ArrayList<String> listMaSP = dbDonDatHang.getAllSanPhams();
        ArrayAdapter<String> adapterMaSP = new ArrayAdapter<String>(this, R.layout.spinner_layout_masp, R.id.tvSpinnerLayoutMaSP,listMaSP);
        spinnerMaSP.setAdapter(adapterMaSP);
    }

    private void setEvent() {
        btnThemDH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addDonHangVaoMang();
            }
        });
    }

    private void addDonHangVaoMang() {

    }
    private void setControl() {
        edtMaDH = findViewById(R.id.nhapMaDH);
        edtSoLuongSP = findViewById(R.id.nhapSoLuongSP);
        edtNgayTaoDH = findViewById(R.id.nhapNgayTaoDH);
        spinnerMaKH = findViewById(R.id.nhapSpinnerMaKH);
        spinnerMaSP = findViewById(R.id.nhapSpinnerMaSP);
        btnThemDH = findViewById(R.id.add_button_dh);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}