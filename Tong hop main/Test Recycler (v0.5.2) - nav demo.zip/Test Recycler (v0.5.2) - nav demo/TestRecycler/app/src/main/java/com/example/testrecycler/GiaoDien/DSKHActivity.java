package com.example.testrecycler.GiaoDien;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.widget.TextView;
import android.widget.Toast;

import com.example.testrecycler.Adapter.CustomAdapterKH;
import com.example.testrecycler.Database.DBKhachHang;
import com.example.testrecycler.Model.KhachHang;
import com.example.testrecycler.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Locale;

public class DSKHActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton add_button;
    Button btnNgonNguAnh, btnNgonNguViet;
    ImageView img_empty;
    TextView khongDuLieu;

    ArrayList<KhachHang> data = new ArrayList<>();
    DBKhachHang myDB = new DBKhachHang(DSKHActivity.this);
    CustomAdapterKH customAdapterKH;
    SwipeRefreshLayout swipeRefreshLayout;

    DrawerLayout drawerLayoutKH;
    NavigationView navigationView;
    Toolbar toolbar;

    //sensors
    private SensorManager mSensorManager;
    private float mAccel; // acceleration apart from gravity
    private float mAccelCurrent; // current acceleration including gravity
    private float mAccelLast; // last acceleration including gravity
    //hop thoai hien trong sensor shake
    static AlertDialog.Builder alertbox;
    static AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_kh);
        setControl();
        setEvent();

//        //Đổi tên actionbar theo ngôn ngữ đã đổi:
//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setTitle(getResources().getString(R.string.app_name));

        luuDatabaseVaoArrays();

    }

    public static void setLocale(String lang, Resources resources) {
        Locale myLocale = new Locale(lang);
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration conf = resources.getConfiguration();
        conf.locale = myLocale;
        resources.updateConfiguration(conf, dm);
    }
    private void refeshLayout(){
        Intent intent = getIntent();
        overridePendingTransition(0, 0);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
        overridePendingTransition(0, 0);
        startActivity(intent);
    }

    private void setEvent() {
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DSKHActivity.this, ThemKHActivity.class);
                startActivity(intent);
            }
        });
//        btnNgonNguViet.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                setLocale("vi",getResources());
//                refeshLayout();
//            }
//        });
//
//        btnNgonNguAnh.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                setLocale("en",getResources());
//                refeshLayout();
//            }
//        });

        //Kéo trái, phải item để xóa + snackbar undo
        new ItemTouchHelper((new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                final int position = viewHolder.getAdapterPosition();
                final KhachHang recoverItem = data.get(position);
                //Lưu giữ id position
                //final int checkingId = data.get(position).getSttKH();
                data.remove(position);
                customAdapterKH.notifyItemRemoved(position);
                //long result = myDB.XoaItemTheoIDKH(checkingId);
                final Snackbar snackbar = Snackbar.make(drawerLayoutKH, "Đã xóa khách hàng", Snackbar.LENGTH_LONG)
                        .setAction("Hoàn Tác", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                data.add(position, recoverItem);
                                customAdapterKH.notifyItemInserted(position);
                                customAdapterKH.notifyDataSetChanged();
                                myDB.ThemKH(recoverItem);
                            }

                        }).addCallback(new Snackbar.Callback() {
                            @Override
                            public void onDismissed(Snackbar snackbar, int dismissType) {
                                super.onDismissed(snackbar, dismissType);
                                if(dismissType == DISMISS_EVENT_TIMEOUT || dismissType == DISMISS_EVENT_SWIPE
                                        || dismissType == DISMISS_EVENT_CONSECUTIVE || dismissType == DISMISS_EVENT_MANUAL
                                        || dismissType == DISMISS_EVENT_ACTION) {
                                    myDB.XoaMotItemKH(recoverItem);
                                }
                            }
                        });
                snackbar.show();
            }
        })) .attachToRecyclerView(recyclerView);

        //Kéo refresh list
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
               luuDatabaseVaoArrays();
               swipeRefreshLayout.setRefreshing(false);
            }
        });

        //Sensor Shake
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        mAccel = 0.00f;
        mAccelCurrent = SensorManager.GRAVITY_EARTH;
        mAccelLast = SensorManager.GRAVITY_EARTH;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    public void luuDatabaseVaoArrays(){
        data = myDB.listKhachHangs();
        if(data.size() > 0){
            recyclerView.setVisibility(View.VISIBLE);
            customAdapterKH = new CustomAdapterKH(DSKHActivity.this,this, data);
            recyclerView.setAdapter(customAdapterKH);
            recyclerView.setLayoutManager(new LinearLayoutManager(DSKHActivity.this));

        }else {
            recyclerView.setVisibility(View.GONE);
            img_empty.setVisibility(View.VISIBLE);
            khongDuLieu.setVisibility(View.VISIBLE);
            String toastMessage = DSKHActivity.this.getResources().getString(R.string.noData);
            Toast.makeText(this,toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

    //Tạo menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        search(searchView);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            confirmXoaTatCa();
        }

        return super.onOptionsItemSelected(item);
    }

    private void search(SearchView searchView) {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (customAdapterKH!=null)
                    customAdapterKH.getFilter().filter(newText);
                return true;
            }
        });
    }

    void confirmXoaTatCa () {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String toastTittle = DSKHActivity.this.getResources().getString(R.string.confirmDeleteAllTittle);
        String toastMessage = DSKHActivity.this.getResources().getString(R.string.confirmDeleteAllMessages);
        String toastYes = DSKHActivity.this.getResources().getString(R.string.confirmYes);
        String toastNo = DSKHActivity.this.getResources().getString(R.string.confirmNo);
        builder.setTitle(toastTittle);
        builder.setMessage(toastMessage);
        builder.setPositiveButton(toastYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBKhachHang myDB = new DBKhachHang(DSKHActivity.this);
                myDB.XoaTatCaKH();
                //Tải lại Activity
                Intent intent = new Intent(DSKHActivity.this, DSKHActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton(toastNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    private final SensorEventListener mSensorListener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent se) {
            float x = se.values[0];
            float y = se.values[1];
            float z = se.values[2];
            mAccelLast = mAccelCurrent;
            mAccelCurrent = (float) Math.sqrt((double) (x*x + y*y + z*z));
            float delta = mAccelCurrent - mAccelLast;
            mAccel = mAccel * 0.9f + delta; // perform low-cut filter

            if (mAccel > 12) {
                String toastTittle = DSKHActivity.this.getResources().getString(R.string.titleDialogShakeKH);
                String toastMessage = DSKHActivity.this.getResources().getString(R.string.messageDialogShakeKH);
                showAlertDialogKH(toastTittle, toastMessage, DSKHActivity.this,true);
            }
        }
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    public static void showAlertDialogKH(final String title, String message,
                                       final Context context, final boolean redirectToPreviousScreen) {
        if (alertDialog != null && alertDialog.isShowing()) {
            // A dialog is already open, wait for it to be dismissed, do nothing
        } else {
            alertbox = new AlertDialog.Builder(context);
            alertbox.setMessage(message);
            alertbox.setTitle(title);
            alertbox.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface arg0, int arg1) {
                    alertDialog.dismiss();
                }
            });
            alertDialog = alertbox.create();
            alertDialog.show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    protected void onPause() {
        mSensorManager.unregisterListener(mSensorListener);
        super.onPause();
    }

    private void setControl() {
        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        img_empty = findViewById(R.id.image_empty);
        khongDuLieu = findViewById(R.id.no_data);
//        btnNgonNguViet = findViewById(R.id.btnNgonNguVN);
//        btnNgonNguAnh = findViewById(R.id.btnNgonNguAnh);
        drawerLayoutKH = findViewById(R.id.drawerLayoutKH);
        swipeRefreshLayout = findViewById(R.id.swipeToRefreshKH);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
    }
}
