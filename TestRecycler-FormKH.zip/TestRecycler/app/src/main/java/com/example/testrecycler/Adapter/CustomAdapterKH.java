package com.example.testrecycler.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.testrecycler.GiaoDien.SuaKHActivity;
import com.example.testrecycler.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CustomAdapterKH extends RecyclerView.Adapter<CustomAdapterKH.MyViewHolder> {
    private Context context;
    private Activity activity;
    private ArrayList kh_id,maKH, tenKH, diaChi, soDT;
    public CustomAdapterKH(Activity activity, Context context,
                           ArrayList kh_id,
                           ArrayList maKH,
                           ArrayList tenKH,
                           ArrayList diaChi,
                           ArrayList soDT){
        this.activity = activity;
        this.context = context;
        this.kh_id = kh_id;
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.diaChi = diaChi;
        this.soDT = soDT;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyclerview_item_kh, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.tvID.setText(String.valueOf(kh_id.get(position)));
        holder.tvMaKH.setText(String.valueOf(maKH.get(position)));
        holder.tvTenKH.setText(String.valueOf(tenKH.get(position)));
        holder.tvDiaChi.setText(String.valueOf(diaChi.get(position)));
        holder.tvSoDT.setText(String.valueOf(soDT.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, SuaKHActivity.class);
                intent.putExtra("id",String.valueOf(kh_id.get(position)));
                intent.putExtra("maKH", String.valueOf(maKH.get(position)));
                intent.putExtra("tenKH", String.valueOf(tenKH.get(position)));
                intent.putExtra("diaChi", String.valueOf(diaChi.get(position)));
                intent.putExtra("soDT", String.valueOf(soDT.get(position)));
                activity.startActivityForResult(intent,1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return kh_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvID, tvMaKH, tvTenKH, tvDiaChi, tvSoDT;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvID = itemView.findViewById(R.id.tvID);
            tvMaKH = itemView.findViewById(R.id.tvMaKH);
            tvTenKH = itemView.findViewById(R.id.tvTenKH);
            tvDiaChi = itemView.findViewById(R.id.tvDiaChi);
            tvSoDT = itemView.findViewById(R.id.tvSoDT);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            //Animate Recyclerview
            //Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            //mainLayout.setAnimation(translate_anim);
        }
    }
}
